console.log("Cargando server.ts...");
import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import multer from "multer";
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const pdf = require("pdf-parse");
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();
console.log("DATABASE_URL cargado:", process.env.DATABASE_URL);

const prisma = new PrismaClient({
  datasources: {
    db: {
      url: process.env.DATABASE_URL,
    },
  },
});
const app = express();
const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || "super-secret-key-tutor-ia";

// Configuración de Multer para subida de archivos
const upload = multer({ storage: multer.memoryStorage() });

app.use(express.json());

// --- MIDDLEWARE DE AUTENTICACIÓN ---
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.status(401).json({ error: "No autorizado" });

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.status(403).json({ error: "Token inválido" });
    req.user = user;
    next();
  });
};

// --- API ROUTES ---

app.use((req, res, next) => {
  console.log(`Petición recibida: ${req.method} ${req.url}`);
  next();
});

// Registro de Usuario
app.post("/api/auth/register", async (req, res) => {
  console.log("Petición recibida en /api/auth/register");
  console.log("Cuerpo de la petición:", req.body);
  try {
    const { email, password, name } = req.body;
    
    if (!email || !password || !name) {
      console.log("Error: Datos incompletos");
      return res.status(400).json({ error: "Datos incompletos" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    console.log("Contraseña hasheada");
    
    const user = await prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        name,
        profile: { create: {} }, // Crear perfil vacío
        subscription: {
          create: {
            expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 días de prueba
          }
        }
      }
    });
    console.log("Usuario creado en BD:", user.id);
    
    res.json({ message: "Usuario creado con éxito" });
  } catch (error: any) {
    console.error("Error en registro:", error);
    res.status(400).json({ error: error.message || "Error desconocido al registrar usuario" });
  }
});

// Login de Usuario
app.post("/api/auth/login", async (req, res) => {
  console.log("Petición recibida en /api/auth/login");
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });
  
  if (user && await bcrypt.compare(password, user.password)) {
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET);
    res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
  } else {
    res.status(401).json({ error: "Credenciales incorrectas" });
  }
});

// Obtener Perfil y Estadísticas
app.get("/api/user/dashboard", authenticateToken, async (req: any, res) => {
  const data = await prisma.user.findUnique({
    where: { id: req.user.id },
    include: { profile: true, subscription: true }
  });
  res.json(data);
});

// --- GESTIÓN DE MATERIAS (ADMIN) ---
app.get("/api/subjects", async (req, res) => {
  const subjects = await prisma.subject.findMany({ include: { categories: true } });
  res.json(subjects);
});

app.post("/api/admin/subjects", authenticateToken, async (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Solo admin" });
  const { name, description, icon } = req.body;
  const subject = await prisma.subject.create({ data: { name, description, icon } });
  res.json(subject);
});

app.post("/api/admin/categories", authenticateToken, async (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Solo admin" });
  const { name, subjectId } = req.body;
  const category = await prisma.category.create({ data: { name, subjectId } });
  res.json(category);
});

// --- PROCESAMIENTO DE CONOCIMIENTO (ADMIN) ---
app.post("/api/admin/upload-knowledge", authenticateToken, upload.single('file'), async (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Solo admin" });
  
  const { categoryId } = req.body;
  const file = req.file;
  
  if (!file) return res.status(400).json({ error: "No hay archivo" });

  let text = "";
  if (file.mimetype === "application/pdf") {
    const data = await pdf(file.buffer);
    text = data.text;
  } else {
    text = file.buffer.toString('utf-8');
  }

  // Dividir en chunks (simplificado)
  const chunks = text.match(/[\s\S]{1,1000}/g) || [];
  
  for (const chunk of chunks) {
    await prisma.knowledgeBase.create({
      data: {
        categoryId,
        content: chunk,
        source: file.originalname
      }
    });
  }

  res.json({ message: "Conocimiento cargado", chunks: chunks.length });
});

// --- CHAT CON TUTOR IA ---
app.post("/api/chat", authenticateToken, async (req: any, res) => {
  const { message, subjectId, categoryId } = req.body;
  
  // 1. Obtener contexto de la base de conocimiento
  const knowledge = await prisma.knowledgeBase.findMany({
    where: { categoryId },
    take: 5 // Tomar los primeros 5 fragmentos (en un sistema real usaríamos búsqueda por vectores)
  });
  
  const context = knowledge.map(k => k.content).join("\n\n");
  
  // 2. Obtener perfil del usuario
  const user = await prisma.user.findUnique({
    where: { id: req.user.id },
    include: { profile: true }
  });

  const profile = user?.profile;

  // 3. Configurar Gemini
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

  const systemInstruction = `
    Eres un tutor experto de la Facultad de Ingeniería (FING, Udelar). 
    Tu objetivo es preparar al estudiante para su evaluación.
    
    CONTEXTO DE LA MATERIA Y CATEGORÍA:
    ${context}
    
    PERFIL DEL ESTUDIANTE:
    - Nivel de abstracción: ${profile?.abstractionLevel}/5
    - Estilo preferido: ${profile?.preferredStyle}
    - Temas dominados: ${profile?.topicsMastered}
    - Temas con dificultad: ${profile?.topicsStruggling}
    
    INSTRUCCIONES:
    - Si el estudiante tiene un nivel bajo, explica con peras y manzanas.
    - Si el nivel es alto, sé más riguroso y formal.
    - Genera ejercicios si el estudiante lo pide.
    - Corrige sus respuestas con paciencia.
    - Enfócate exclusivamente en el contexto proporcionado.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: message,
      config: {
        systemInstruction: systemInstruction,
      },
    });

    const responseText = response.text || "Lo siento, no pude generar una respuesta.";

    // Guardar mensajes
    await prisma.chatMessage.createMany({
      data: [
        { userId: req.user.id, role: "user", content: message, subjectId, categoryId },
        { userId: req.user.id, role: "assistant", content: responseText, subjectId, categoryId }
      ]
    });

    // Simulación de actualización de perfil (heurística simple)
    if (message.length > 100) {
      await prisma.userProfile.update({
        where: { userId: req.user.id },
        data: { abstractionLevel: { increment: profile?.abstractionLevel! < 5 ? 1 : 0 } }
      });
    }

    res.json({ text: responseText });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error en la IA" });
  }
});

// --- VITE MIDDLEWARE ---
async function startServer() {
  console.log("Iniciando startServer...");
  if (process.env.NODE_ENV !== "production") {
    console.log("Configurando Vite middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite middleware configurado.");
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
    console.log("Listo para recibir peticiones.");
  });
}

startServer().catch((err) => {
  console.error("Error al iniciar el servidor:", err);
  process.exit(1);
});
