import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando siembra de datos...');

  // 1. Crear Admin
  const adminPassword = await bcrypt.hash('admin123', 10);
  await prisma.user.upsert({
    where: { email: 'admin@tutoria.uy' },
    update: {},
    create: {
      email: 'admin@tutoria.uy',
      password: adminPassword,
      name: 'Administrador',
      role: 'ADMIN',
      profile: { create: {} },
      subscription: {
        create: {
          status: 'active',
          expiresAt: new Date(2030, 0, 1)
        }
      }
    }
  });

  // 2. Crear Materia: Cálculo 1
  const calculo1 = await prisma.subject.upsert({
    where: { name: 'Cálculo 1' },
    update: {},
    create: {
      name: 'Cálculo 1',
      description: 'Cálculo diferencial e integral en una variable. Incluye límites, derivadas, integrales y series.',
      icon: 'BookOpen',
      categories: {
        create: [
          { name: 'Prácticos Semanales' },
          { name: 'Primer Parcial' },
          { name: 'Segundo Parcial' },
          { name: 'Examen Final' }
        ]
      }
    }
  });

  console.log('✅ Datos sembrados con éxito');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
