import { GoogleGenAI } from "@google/genai";

const API_URL = "/api";

export const authService = {
  async login(email: string, password: string) {
    const res = await fetch(`${API_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) throw new Error("Login fallido");
    const data = await res.json();
    localStorage.setItem("token", data.token);
    localStorage.setItem("user", JSON.stringify(data.user));
    return data;
  },
  
  async register(email: string, password: string, name: string) {
    const res = await fetch(`${API_URL}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, name }),
    });
    if (!res.ok) throw new Error("Registro fallido");
    return res.json();
  },
  
  logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/";
  },
  
  getToken() {
    return localStorage.getItem("token");
  },
  
  getUser() {
    const user = localStorage.getItem("user");
    return user ? JSON.parse(user) : null;
  }
};

export const dataService = {
  async getDashboard() {
    const res = await fetch(`${API_URL}/user/dashboard`, {
      headers: { "Authorization": `Bearer ${authService.getToken()}` }
    });
    return res.json();
  },
  
  async getSubjects() {
    const res = await fetch(`${API_URL}/subjects`);
    return res.json();
  },
  
  async sendMessage(message: string, subjectId: string, categoryId: string) {
    const res = await fetch(`${API_URL}/chat`, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Authorization": `Bearer ${authService.getToken()}`
      },
      body: JSON.stringify({ message, subjectId, categoryId }),
    });
    return res.json();
  }
};

export const adminService = {
  async createSubject(data: any) {
    const res = await fetch(`${API_URL}/admin/subjects`, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Authorization": `Bearer ${authService.getToken()}`
      },
      body: JSON.stringify(data),
    });
    return res.json();
  },
  
  async uploadKnowledge(formData: FormData) {
    const res = await fetch(`${API_URL}/admin/upload-knowledge`, {
      method: "POST",
      headers: { 
        "Authorization": `Bearer ${authService.getToken()}`
      },
      body: formData,
    });
    return res.json();
  }
};
